import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Scanner;

public class CurrencyConverter {
    private static final OkHttpClient client = new OkHttpClient();
    private static final String API_URL = "https://api.exchangerate.host/convert";

    public static double convert(String from, String to, double amount) throws IOException {
        String url = API_URL + "?from=" + from + "&to=" + to + "&amount=" + amount;

        Request request = new Request.Builder()
                .url(url)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Erro na requisição: " + response);
            }

            String jsonData = response.body().string();
            JSONObject json = new JSONObject(jsonData);

            return json.getDouble("result");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("De (ex: USD): ");
        String from = scanner.nextLine().toUpperCase();

        System.out.print("Para (ex: BRL): ");
        String to = scanner.nextLine().toUpperCase();

        System.out.print("Valor: ");
        double amount = scanner.nextDouble();

        try {
            double result = convert(from, to, amount);
            System.out.printf("%.2f %s = %.2f %s%n", amount, from, result, to);
        } catch (IOException e) {
            System.out.println("Erro ao converter moeda: " + e.getMessage());
        }
    }
}
